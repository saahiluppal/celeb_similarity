import torch
from fastapi import FastAPI, File, UploadFile
from model import Inf_Net_UNet
import io

from PIL import Image
from tempfile import NamedTemporaryFile
import imageio
import numpy as np


import requests
import torchvision as tv



app = FastAPI(title="Covid CT Segmentation")

model = None

TEST_SIZE = 352

INPUT_CHANNELS = 6
NUM_CLASSES = 3

transform = tv.transforms.Compose([
    tv.transforms.Resize((TEST_SIZE, TEST_SIZE)),
    tv.transforms.ToTensor(),
    tv.transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])])


def prepare_image(image, psuedo_url):

    psuedo_image = Image.open(requests.get(psuedo_url, stream=True).raw)

    if psuedo_image.mode != "RGB":
        psuedo_image = psuedo_image.convert("RGB")

    if image.mode != "RGB":
        image = image.convert("RGB")

    image = transform(image).unsqueeze(0)
    psuedo_image = transform(psuedo_image).unsqueeze(0)

    return image, psuedo_image


def split_class(path, w, h):
    im = Image.open(path).convert('L')
    im_array_red = np.array(im)  # 0, 38
    im_array_green = np.array(im)  # 0, 75
    
    uniquemidfinder = np.unique(im_array_red)
    mid = uniquemidfinder[1]
    print(np.unique(im_array_red))

    im_array_red[im_array_red != 0] = 1
    im_array_red[im_array_red == 0] = 255
    im_array_red[im_array_red == 1] = 0

    im_array_green[im_array_green != mid] = 0
    im_array_green[im_array_green == mid] = 255

    # Class1 = GroundGlassOpacities
    # Class2 = Consolidation
    class_one = Image.fromarray(im_array_red).convert('1').resize(size=(h, w))
    class_two = Image.fromarray(im_array_green).convert('1').resize(size=(h, w))

    return class_one, class_two

@app.on_event("startup")
def load_model():
    device = "cuda" if torch.cuda.is_available() else "cpu"

    global model
    model = Inf_Net_UNet(INPUT_CHANNELS, NUM_CLASSES)

    model_state = torch.hub.load_state_dict_from_url("https://github.com/saahiluppal/Inf-Net/releases/download/v1.0/unet_model_200.pkl",
                                    map_location=device, progress=True)
    model.load_state_dict(model_state)

    model.to(device)
    model.eval()


@app.post("/api/ctlungmulticlass")
async def inference(ctscan: UploadFile = File(...), PsuedoUrl: str = None):

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    content = await ctscan.read()
    image = Image.open(io.BytesIO(content))

    image, psuedo_image = prepare_image(image, PsuedoUrl)


    with torch.no_grad():
        image = image.to(device)
        psuedo_image = psuedo_image.to(device)

        output = model(torch.cat((image, psuedo_image), dim=1))
        output = torch.sigmoid(output)  # output.shape is torch.Size([4, 2, 160, 160])
        b, _, w, h = output.size()

        pred = output.cpu().permute(0, 2, 3, 1).contiguous().view(-1, NUM_CLASSES).max(1)[1].view(b, w, h).numpy().squeeze()
        print('Class numbers of prediction in total:', np.unique(pred))


        with NamedTemporaryFile() as temp:
            iname = "".join([str(temp.name),".png"])
            imageio.imwrite(iname, pred)

            class_one, class_two = split_class(iname, w, h)

            class_one.save("one.jpeg")
            class_two.save("two.jpeg")

        return {"success": True}




#if __name__ == "__main__":
#    inference(num_classes=3,
#              input_channels=6,
#              snapshot_dir='./Snapshots/save_weights/Semi-Inf-Net_UNet/unet_model_200.pkl',
#              save_path='./Results/Multi-class lung infection segmentation/class_12/'
#              )
